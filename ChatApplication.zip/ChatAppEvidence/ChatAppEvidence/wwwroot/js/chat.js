﻿"use strict";

const connection = new signalR.HubConnectionBuilder().withUrl("http://localhost:5191/chatHub").configureLogging(signalR.LogLevel.Information).build();
const start = async () => {
    try {
        await connection.start();
    }
    catch (error) {
        console.log(error);
    }
}
const joinUser = async () => {
    const name = window.prompt('Enter your name');
    if (name) {
        sessionStorage.setItem('user', name);
        await joinChat(name);
    }
}
const joinChat = async (user) => {
    if (!user)
        return;
    try {
        const message = `${user} joined`;
        await connection.invoke("JoinChat", user, message )
    }
    catch (error) {
        console.log(error);
    }
}
const getUser = () => sessionStorage.getItem('user');

const receiveMessage = async () => {
    const currentUser = getUser();
    if (!currentUser)
        return;

    try {
        await connection.on("ReceiveMessage", (user, message) => {
            const messageClass = currentUser == user ? "send" : "received";
            appendMessage(message, messageClass);
        })
    }
    catch (error) {
        console.log(error);
    }
}
const appendMessage = (message, messageClass) => {
    const messageSectionEL = document.getElementById('messageSection');
    const msgBoxEL = document.createElement("div");
    msgBoxEL.classList.add("msg-box");
    msgBoxEL.classList.add(messageClass);
    msgBoxEL.innerHTML = message;
    messageSectionEL.appendChild(msgBoxEL);
}
document.getElementById('btnSend').addEventListener('click', async (e) => {
    e.preventDefault();   
    const user = getUser();
    if (!user)
        return;
    const txtmessageEL = document.getElementById('txtMessage');
    const msg = txtmessageEL.value;
    if (msg) {
        await sendMessage(user, `${user}: ${msg}`)
        txtmessageEL.value = "";
    }
})
const sendMessage = async (user, message) => {
    try {
        await connection.invoke('SendMessage', user, message)
    }
    catch (error) {
        console.log(error);
    }
}
const startApp = async () => {
    await start();
    await joinUser();
    await receiveMessage();
}
startApp();
